import pymysql
import paramiko
from paramiko import SSHClient
import sshtunnel
from sshtunnel import SSHTunnelForwarder

mypkey = paramiko.RSAKey.from_private_key_file("C:\\Users\\shih\ActuaViz\\treasurance_info_yoyo_actuviz\\treasurance_info_yoyo_actuviz.pem")

sql_hostname = 'treasurance-info-db.ciiomwpipnuy.ap-northeast-1.rds.amazonaws.com'
sql_username = 'yoyo'
sql_password = 'Xgeej6534'
sql_main_database = 'treasurance_info_db'
sql_port = 3306
ssh_host = 'ec2-18-181-70-135.ap-northeast-1.compute.amazonaws.com'
ssh_user = 'yoyo_actuviz'
ssh_port = 22
sql_ip = '1.1.1.1.1'

with SSHTunnelForwarder(
        (ssh_host, ssh_port),
        ssh_username=ssh_user,
        ssh_pkey=mypkey,
        remote_bind_address=(sql_hostname, sql_port)) as tunnel:
    conn = pymysql.connect(host='127.0.0.1', user=sql_username,
            passwd=sql_password, db=sql_main_database,
            port=tunnel.local_bind_port)
    cursor = conn.cursor()
    conn.close()

# DB Operations
def getLifeTable():
   return