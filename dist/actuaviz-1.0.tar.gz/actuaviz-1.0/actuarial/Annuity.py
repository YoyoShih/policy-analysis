import math
import pandas as pd
import Benefit
''' Notation '''
# x: age    # omega: age end    # i: interest rate

# Basic parameters; Would not change
''' File Settings '''
root_path = 'C:/Users/shih/ActuaViz/'
mortTable = pd.read_csv(f'{root_path}2021TSO.csv')

''' Basic Annuity Functions '''
def a_imm_n(n, i=0.02):
    v = 1 / (1 + i)
    return (1 - v ** n) / i

def a_due_n(n, i=0.02):
    v = 1 / (1 + i)
    d = 1 - v
    return (1 - v ** n) / d

def a_bar_n(n, i=0.02):
    v = 1 / (1 + i)
    delta = math.log(1 + i)
    return (1 - v ** n) / delta

def a_imm_m_n(n, m, i=0.02):
    v = 1 / (1 + i)
    i_m = m * ((1 + i) ** (1 / m) - 1)
    return (1 - v ** n) / i_m

def a_due_m_n(n, m, i=0.02):
    v = 1 / (1 + i)
    d_m = m * (1 - v ** (1 / m))
    return (1 - v ** n) / d_m

''' Other Functions '''
def alpha(m, i=0.02):
    v = 1 / (1 + i)
    d = 1 - v
    i_m = m * ((1 + i) ** (1 / m) - 1)
    d_m = m * (1 - v ** (1 / m))
    return i * d / (i_m * d_m)

def beta(m, i=0.02):
    v = 1 / (1 + i)
    i_m = m * ((1 + i) ** (1 / m) - 1)
    d_m = m * (1 - v ** (1 / m))
    return (i - i_m) / (i_m * d_m)

''' Whole Life Annuity Functions '''
def a_due_x(x, gender, omega=105, i=0.02):
    survivals = 1
    a = 0
    discount = 1
    
    for year in range(omega - x):
        a += survivals * discount
        index = (mortTable["Gender"] == gender) & (mortTable["Age"] == x + year)
        mort_rate = mortTable[index]["MortRate"].tolist()[0] if year < omega - x - 1 else 1
        survivals *= (1 - mort_rate)
        discount /= (1 + i)
    
    return a

def a_imm_x(x, gender, omega=105, i=0.02):
    survivals = 1
    a = 0
    discount = 1
    
    for year in range(1, omega - x + 1):
        a += survivals * discount
        index = (mortTable["Gender"] == gender) & (mortTable["Age"] == x + year)
        mort_rate = mortTable[index]["MortRate"].tolist()[0] if year < omega - x else 1
        survivals *= (1 - mort_rate)
        discount /= (1 + i)
    
    return a

def a_due_m_x(x, gender, m, omega=105, i=0.02, method=0):
    delta = math.log(1 + i)
    # UDD assumption
    if method == 0:
        return alpha(m, i=i) * a_due_x(x, gender, omega=omega, i=i) - beta(m, i=i)
    # Woolhouse's formula
    else:
        index = (mortTable["Gender"] == gender) & (mortTable["Age"] == x - 1) if x > 0 else 1
        p_1 = mortTable[index]["MortRate"].tolist()[0]
        index = (mortTable["Gender"] == gender) & (mortTable["Age"] == x)
        p_2 = mortTable[index]["MortRate"].tolist()[0]
        mu_x = -(math.log(p_1) + math.log(p_2)) / 2
        return a_due_x(x, gender, omega=omega, i=i) - (m - 1) / (2 * m) - (delta + mu_x) * (m ** 2 - 1) / (12 * m ** 2)

def a_conti_x(x, gender, omega=105, i=0.02, method=0):
    v = 1 / (1 + i)
    d = 1 - v
    delta = math.log(1 + i)
    # UDD assumption
    if method == 0:
        return i * d * a_due_x(x, gender, omega=omega, i=i) / (delta ** 2) - (i - delta) / (delta ** 2)
    # Woolhouse's formula
    else:
        index = (mortTable["Gender"] == gender) & (mortTable["Age"] == x - 1) if x > 0 else 1
        p_1 = mortTable[index]["MortRate"].tolist()[0]
        index = (mortTable["Gender"] == gender) & (mortTable["Age"] == x)
        p_2 = mortTable[index]["MortRate"].tolist()[0]
        mu_x = -(math.log(p_1) + math.log(p_2)) / 2
        return a_due_x(x, gender, omega=omega, i=i) - 0.5 - (delta + mu_x) / 12

''' Term Annuity Functions '''
def a_due_x_n(x, gender, n, omega=105, i=0.02):
    survivals = 1
    a = 0
    discount = 1
    
    for year in range(min(omega - x, n)):
        a += survivals * discount
        index = (mortTable["Gender"] == gender) & (mortTable["Age"] == x + year)
        mort_rate = mortTable[index]["MortRate"].tolist()[0] if year < min(omega - x, n) - 1 else 1
        survivals *= (1 - mort_rate)
        discount /= (1 + i)
    
    return a

def a_imm_x_n(x, gender, n, omega=105, i=0.02):
    survivals = 1
    a = 0
    discount = 1
    
    for year in range(1, min(omega - x, n) + 1):
        a += survivals * discount
        index = (mortTable["Gender"] == gender) & (mortTable["Age"] == x + year)
        mort_rate = mortTable[index]["MortRate"].tolist()[0] if year < min(omega - x, n) else 1
        survivals *= (1 - mort_rate)
        discount /= (1 + i)
    
    return a

def a_due_m_x_n(x, gender, m, n, omega=105, i=0.02, method=0):
    v = 1 * (1 + i)
    delta = math.log(1 + i)

    p_n = 1
    for year in range(min(omega - x, n)):
        index = (mortTable["Gender"] == gender) & (mortTable["Age"] == x + year)
        mort_rate = mortTable[index]["MortRate"].tolist()[0]
        p_n *= (1 - mort_rate)

    # UDD assumption
    if method == 0:
        return alpha(m, i=i) * a_due_x(x, gender, omega=omega, i=i) - beta(m, i=i) * (1 - v ** n * p_n)
    # Woolhouse's formula
    else:
        index = (mortTable["Gender"] == gender) & (mortTable["Age"] == x - 1) if x > 0 else 1
        p_1 = mortTable[index]["MortRate"].tolist()[0]
        index = (mortTable["Gender"] == gender) & (mortTable["Age"] == x)
        p_2 = mortTable[index]["MortRate"].tolist()[0]
        mu_x = -(math.log(p_1) + math.log(p_2)) / 2

        index = (mortTable["Gender"] == gender) & (mortTable["Age"] == x + n - 1) if x + n > 0 else 1
        p_1 = mortTable[index]["MortRate"].tolist()[0]
        index = (mortTable["Gender"] == gender) & (mortTable["Age"] == x + n)
        p_2 = mortTable[index]["MortRate"].tolist()[0]
        mu_xn = -(math.log(p_1) + math.log(p_2)) / 2

        return a_due_x(x, gender, omega=omega, i=i) - (1 - v ** n * p_n) * (m - 1) / (2 * m) - (delta + mu_x - v ** n * p_n * (delta + mu_xn)) * (m ** 2 - 1) / (12 * m ** 2)

def a_conti_x_n(x, gender, n, omega=105, i=0.02, method=0):
    v = 1 / (1 + i)
    d = 1 - v
    delta = math.log(1 + i)

    p_n = 1
    for year in range(min(omega - x, n)):
        index = (mortTable["Gender"] == gender) & (mortTable["Age"] == x + year)
        mort_rate = mortTable[index]["MortRate"].tolist()[0]
        p_n *= (1 - mort_rate)

    # UDD assumption
    if method == 0:
        return i * d * a_due_x_n(x, gender, n, omega=omega, i=i) / (delta ** 2) - (i - delta) * (1 - v ** n * p_n) / (delta ** 2)
    # Woolhouse's formula
    else:
        index = (mortTable["Gender"] == gender) & (mortTable["Age"] == x - 1) if x > 0 else 1
        p_1 = mortTable[index]["MortRate"].tolist()[0]
        index = (mortTable["Gender"] == gender) & (mortTable["Age"] == x)
        p_2 = mortTable[index]["MortRate"].tolist()[0]
        mu_x = -(math.log(p_1) + math.log(p_2)) / 2
        
        index = (mortTable["Gender"] == gender) & (mortTable["Age"] == x + n - 1) if x + n > 0 else 1
        p_1 = mortTable[index]["MortRate"].tolist()[0]
        index = (mortTable["Gender"] == gender) & (mortTable["Age"] == x + n)
        p_2 = mortTable[index]["MortRate"].tolist()[0]
        mu_xn = -(math.log(p_1) + math.log(p_2)) / 2

        return a_due_x_n(x, gender, n, omega=omega, i=i) - (1 - v ** n * p_n) / 2 - (delta + mu_x - v ** n * p_n * (delta + mu_xn)) / 12
