import math
import pandas as pd
''' Notation '''
# x: age    # omega: age end    # i: interest rate

# Basic parameters; Would not change
''' File Settings '''
root_path = 'C:/Users/shih/ActuaViz/'
mortTable = pd.read_csv(f'{root_path}2021TSO.csv')

# Whole Life Insurance Functions
''' Whole Life Insurance, continuous case '''
def A_bar_x(x, gender, omega=105, i=0.02, method=0):
    # UDD assumption
    if method == 0:
        delta = math.log(1 + i)
        return A_x(x, gender, omega=omega, i=i) * i / delta
    # Claims acceleration approach
    elif method == 1:
        return A_x(x, gender, omega=omega, i=i) * (1 + i) ** 0.5

''' Whole Life Insurance, annual case '''
def A_x(x, gender, omega=105, i=0.02):
    survivals = 1
    A = 0
    discount = (1 + i) ** -1
    
    for year in range(omega - x):
        index = (mortTable["Gender"] == gender) & (mortTable["Age"] == x + year)
        mort_rate = mortTable[index]["MortRate"].tolist()[0] if year < omega - x - 1 else 1
        deaths = survivals * mort_rate
        A += deaths * discount
        survivals -= deaths
        discount /= (1 + i)
    
    return A

''' Whole Life Insurance, 1/mthly case '''
def A_m_x(x, gender, m, omega=105, i=0.02, method=0):
    # UDD assumption
    if method == 0:
        i_m = m * ((1 + i) ** (1 / m) - 1)
        return A_x(x, gender, omega=omega, i=i) * i / i_m
    # Claims acceleration approach
    elif method == 1:
        return A_x(x, gender, omega=omega, i=i) * (1 + i) ** ((m - 1) / (2 * m))

# Term Insurance Functions
''' Term Life Insurance, continuous case '''
def A_bar_1_x_n(x, gender, n, omega=105, i=0.02, method=0):
    # UDD assumption
    if method == 0:
        delta = math.log(1 + i)
        return A_1_x_n(x, gender, n, omega=omega, i=i) * i / delta
    # Claims acceleration approach
    elif method == 1:
        return A_1_x_n(x, gender, n, omega=omega, i=i) * (1 + i) ** 0.5

''' Term Life Insurance, annual case '''
def A_1_x_n(x, gender, n, omega=105, i=0.02):
    survivals = 1
    A = 0
    discount = (1 + i) ** -1
    
    for year in range(min(n, omega - x)):
        index = (mortTable["Gender"] == gender) & (mortTable["Age"] == x + year)
        mort_rate = mortTable[index]["MortRate"].tolist()[0] if year < min(n, omega - x) - 1 else 1
        deaths = survivals * mort_rate
        A += deaths * discount
        survivals -= deaths
        discount /= (1 + i)
    
    return A

''' Term Life Insurance, 1/mthly case '''
def A_m_1_x_n(x, gender, m, n, omega=105, i=0.02, method=0):
    # UDD assumption
    if method == 0:
        i_m = m * ((1 + i) ** (1 / m) - 1)
        return A_1_x_n(x, gender, n, omega=omega, i=i) * i / i_m
    # Claims acceleration approach
    elif method == 1:
        return A_1_x_n(x, gender, n, omega=omega, i=i) * (1 + i) ** ((m - 1) / (2 * m))

# Endowment Insurance FUnctions
''' Pure Endowment '''
def nEx(x, gender, n, omega=105, i=0.02):
    survivals = 1

    for year in range(min(n, omega - x)):
        index = (mortTable["Gender"] == gender) & (mortTable["Age"] == x + year)
        mort_rate = mortTable[index]["MortRate"].tolist()[0] if year < min(n, omega - x) - 1 else 1
        deaths = survivals * mort_rate
        survivals -= deaths

    return survivals / (1 + i) ** n

''' Endowment Insurance, continuous case '''
def A_bar_x_n(x, gender, n, omega=105, i=0.02, method=0):
    return A_bar_1_x_n(x, gender, n, omega=omega, i=i, method=method) + nEx(x, gender, n, omega=omega, i=i)

''' Endowment Insurance, annual case '''
def A_x_n(x, gender, n, omega=105, i=0.02):
    return A_1_x_n(x, gender, n, omega=omega, i=i) + nEx(x, gender, n, omega=omega, i=i)

''' Endowment Insurance, 1/mthly case '''
def A_m_x_n(x, gender, m, n, omega=105, i=0.02, method=0):
    return A_m_1_x_n(x, gender, m, n, omega=omega, i=i, method=method) + nEx(x, gender, n, omega=omega, i=i)